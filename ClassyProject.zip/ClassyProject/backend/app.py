from flask import Flask, request, jsonify
from flask_cors import CORS
from pymongo import MongoClient
from werkzeug.security import generate_password_hash, check_password_hash
from dotenv import load_dotenv
from bson import ObjectId
from datetime import datetime
import os

load_dotenv()

app = Flask(__name__)
CORS(app)

client = MongoClient(os.getenv("MONGO_URI", "mongodb://127.0.0.1:27017/"))
db = client["classly_db"]

users = db["users"]
rooms = db["rooms"]
bookings = db["bookings"]


def serialize(document):
    document["_id"] = str(document["_id"])
    return document


@app.get("/api/health")
def health():
    return jsonify({"message": "Classly backend is running"})


@app.post("/api/register")
def register():
    data = request.get_json(silent=True) or {}
    name = data.get("name", "").strip()
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")
    role = data.get("role", "Student")

    if not name or not email or not password:
        return jsonify({"error": "Name, email, and password are required"}), 400
    if users.find_one({"email": email}):
        return jsonify({"error": "Email already registered"}), 409

    users.insert_one({
        "name": name,
        "email": email,
        "password": generate_password_hash(password),
        "role": role,
        "created_at": datetime.utcnow()
    })
    return jsonify({"message": "Registration successful"}), 201


@app.post("/api/login")
def login():
    data = request.get_json(silent=True) or {}
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")

    user = users.find_one({"email": email})
    if not user or not check_password_hash(user["password"], password):
        return jsonify({"error": "Invalid email or password"}), 401

    return jsonify({
        "message": "Login successful",
        "user": {
            "id": str(user["_id"]),
            "name": user["name"],
            "email": user["email"],
            "role": user["role"]
        }
    })


@app.get("/api/rooms")
def get_rooms():
    return jsonify([serialize(room) for room in rooms.find()])


@app.post("/api/rooms")
def add_room():
    data = request.get_json(silent=True) or {}
    name = data.get("name", "").strip()
    if not name:
        return jsonify({"error": "Room name is required"}), 400

    room = {
        "name": name,
        "building": data.get("building", ""),
        "capacity": int(data.get("capacity", 0)),
        "status": data.get("status", "Available"),
        "features": data.get("features", [])
    }
    result = rooms.insert_one(room)
    return jsonify({"message": "Room added", "id": str(result.inserted_id)}), 201


@app.get("/api/bookings")
def get_bookings():
    return jsonify([serialize(booking) for booking in bookings.find().sort("created_at", -1)])


@app.post("/api/bookings")
def create_booking():
    data = request.get_json(silent=True) or {}
    required = ["room", "faculty", "date", "start_time", "end_time", "purpose", "students"]
    if any(data.get(field) in (None, "") for field in required):
        return jsonify({"error": "Please provide all booking details"}), 400

    if data["end_time"] <= data["start_time"]:
        return jsonify({"error": "End time must be later than start time"}), 400

    conflict = bookings.find_one({
        "room": data["room"],
        "date": data["date"],
        "status": {"$ne": "Cancelled"},
        "start_time": {"$lt": data["end_time"]},
        "end_time": {"$gt": data["start_time"]}
    })
    if conflict:
        return jsonify({"error": "This room is already booked for that time"}), 409

    booking = {
        "room": data["room"],
        "faculty": data["faculty"],
        "date": data["date"],
        "start_time": data["start_time"],
        "end_time": data["end_time"],
        "purpose": data["purpose"],
        "students": int(data["students"]),
        "status": "Pending",
        "created_at": datetime.utcnow()
    }
    result = bookings.insert_one(booking)
    return jsonify({"message": "Booking request created", "id": str(result.inserted_id)}), 201


@app.put("/api/bookings/<booking_id>")
def update_booking(booking_id):
    data = request.get_json(silent=True) or {}
    status = data.get("status")
    if status not in ["Pending", "Approved", "Cancelled"]:
        return jsonify({"error": "Status must be Pending, Approved, or Cancelled"}), 400

    try:
        result = bookings.update_one(
            {"_id": ObjectId(booking_id)},
            {"$set": {"status": status}}
        )
    except Exception:
        return jsonify({"error": "Invalid booking ID"}), 400

    if result.matched_count == 0:
        return jsonify({"error": "Booking not found"}), 404
    return jsonify({"message": "Booking updated"})


if __name__ == "__main__":
    app.run(debug=True, port=5000)
