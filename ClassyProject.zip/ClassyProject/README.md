# Classly Project (Frontend + Backend)

## Folder structure
- `frontend/index.html`: Classly UI (markup)
- `frontend/css/style.css`: Styles
- `frontend/js/app.js`: Frontend logic
- `frontend/assets/`: Images and static assets
- `backend/app.py`: Flask API
- `backend/requirements.txt`: Python dependencies
- `backend/.env`: Local MongoDB connection

## Run the backend
1. Make sure MongoDB is running locally.
2. Open a terminal in the `backend` folder.
3. Install packages:
   `pip install -r requirements.txt`
4. Start Flask:
   `python app.py`
5. Test:
   `http://127.0.0.1:5000/api/health`

## Run the frontend
Open `frontend/index.html` in VS Code and choose **Open with Live Server**.

Keep the Flask terminal and Live Server open together.

## API routes included
- `GET /api/health`
- `POST /api/register`
- `POST /api/login`
- `GET /api/rooms`
- `POST /api/rooms`
- `GET /api/bookings`
- `POST /api/bookings`
- `PUT /api/bookings/<booking_id>`

Note: The provided HTML still has demo/sample data and local-only login behavior. This starter backend is included, but frontend JavaScript must be wired to these APIs for real data persistence. The AI assistant, faculty, subjects, timetable, and reporting features are not yet backed by database APIs.
